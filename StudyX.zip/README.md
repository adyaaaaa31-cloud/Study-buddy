# StudyX

A simple study planner for Android (and any browser). Installable as an app.

## Features
- Add and delete tasks
- Set deadlines (overdue tasks are highlighted)
- Track completed tasks with a progress bar
- Dark mode (remembers your choice)
- Tasks save automatically on your phone
- Works offline once installed

## Put it on GitHub
1. Create a new empty repository on github.com (for example `studyx`).
2. In this folder, run:
   ```
   git init
   git add .
   git commit -m "StudyX"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/studyx.git
   git push -u origin main
   ```
   (Or use "Add file > Upload files" on GitHub and drop in everything from this folder, including the `.github` folder.)
3. On GitHub, open **Settings > Pages**, and set **Source** to **GitHub Actions**.
4. Open the **Actions** tab and wait for "Deploy StudyX to GitHub Pages" to finish (about a minute).
5. Your app is live at `https://YOUR-USERNAME.github.io/studyx/`.

## Easiest option if the .github folder won't upload (phones)
Mobile browsers often skip hidden folders. If that happens, you don't need the workflow at all:
1. Upload the other files to your repository.
2. Go to **Settings > Pages**, set **Source** to **Deploy from a branch**, choose **main** and **/ (root)**, then **Save**.
3. Your app goes live at `https://YOUR-USERNAME.github.io/REPO-NAME/` in about a minute.

Prefer the automatic workflow? Create a new file on GitHub named `.github/workflows/pages.yml` and paste in the contents of `github-workflow-pages.yml`.

## Install on your Android phone
1. Open your GitHub Pages link in Chrome.
2. Tap the menu (three dots), then **Install app** (or **Add to Home screen**).
3. Open StudyX from your home screen like any other app.

## Files
- `index.html` the whole app (HTML, CSS, JS)
- `manifest.json` install details
- `sw.js` offline support
- `icons/` app icons
- `.github/workflows/pages.yml` automatic deployment
